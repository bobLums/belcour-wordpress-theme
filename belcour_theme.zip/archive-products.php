<?php get_header();?>

<div class="page-wrap">
	<div class="container mb-5">
		<h1>Products</h1>
		
		<h2>Hots</h2>
		<div class="row">
			<?php
			$args = array( 'post_type' => 'Products', 
				            'numberposts' => 3,
							'order_by' => 'publish_date',
							'order' => 'ASC',
							'tax_query' => array(
								array(	'taxonomy' => 'preserves',
										'field'    => 'slug',
										'terms'    => 'hots',
								),
						),);
			$prods = get_posts( $args );
			foreach($prods as $post) : setup_postdata($post); ?> 
				<div class="col-md-4">
					<?php if(has_post_thumbnail()):?>
		                <img src="<?php the_post_thumbnail_url(__('(more�)'))?>" alt="<?php the_title();?>" class="img-fluid mx-auto mb-2">
	                    <?php endif;?>
	                    <h3><?php the_title();?></h3>
						<div class="prodlink">
							<p><?php the_field('short');?></p>
							<a href="<?php the_permalink();?>">Read more</a>
						</div>
	                    <br><br>
                </div>
            <?php endforeach; ?>
		</div>

		<h2>Savouries</h2>
		<div class="row">
			<?php
			$args = array( 'post_type' => 'Products', 
				            'numberposts' => 3,
							'order_by' => 'publish_date',
							'order' => 'ASC',
							'tax_query' => array(
								array(	'taxonomy' => 'preserves',
										'field'    => 'slug',
										'terms'    => 'savouries',
								),
						),);
			$prods = get_posts( $args );
			foreach($prods as $post) : setup_postdata($post); ?> 
				<div class="col-md-4">
					<?php if(has_post_thumbnail()):?>
		                <img src="<?php the_post_thumbnail_url(__('(more�)'))?>" alt="<?php the_title();?>" class="img-fluid mx-auto mb-2">
	                    <?php endif;?>
	                    <h3><?php the_title();?></h3>
	                    <div class="prodlink">
							<p><?php the_field('short');?></p>
							<a href="<?php the_permalink();?>">Read more</a>
						</div>
	                    <br><br>
                </div>
            <?php endforeach; ?>
		</div>

		<h2>Sweets</h2>
		<div class="row">
			<?php
			$args = array( 'post_type' => 'Products', 
				            'numberposts' => 3,
							'order_by' => 'publish_date',
							'order' => 'ASC',
							'tax_query' => array(
								array(	'taxonomy' => 'preserves',
										'field'    => 'slug',
										'terms'    => 'sweets',
								),
						),);
			$prods = get_posts( $args );
			foreach($prods as $post) : setup_postdata($post); ?> 
				<div class="col-md-4">
					<?php if(has_post_thumbnail()):?>
		                <img src="<?php the_post_thumbnail_url(__('(more�)'))?>" alt="<?php the_title();?>" class="img-fluid mx-auto mb-2">
	                    <?php endif;?>
	                    <h3><?php the_title();?></h3>
	                    <div class="prodlink">
							<p><?php the_field('short');?></p>
							<a href="<?php the_permalink();?>">Read more</a>
						</div>
	                    <br><br>
                </div>
            <?php endforeach; ?>
		</div>

</div>

<?php get_footer();?>


