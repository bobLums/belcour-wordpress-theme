<?php
/*
Template Name: Cookbook
*/
?>
<?php get_header();?>
<div class="page-wrap">
	<div class="container mb-5">
		<h1>The Belcour Cookbook</h1>
		<div class="row mb-5">
			<div class="col-sm-4">
				<div class="mx-auto">
					<?php if(has_post_thumbnail()):?>
						<img src="<?php the_post_thumbnail_url(__('(more�)'))?>" alt="<?php the_title();?>" class="img-fluid">
					<?php endif;?>
				</div>
			</div>
			<div class="col-sm-8">
				<h2 style="text-align:left;"><?php the_field('main_tag');?></h2>
				<p><?php the_field('main_desc');?></p>
				<a href="https://www.amazon.com/Belcour-Cookbook-Robin-Lim-Lumsden/dp/9768246081/ref=sr_1_1?dchild=1&keywords=the+belcour+cookbook&qid=1593274531&sr=8-1#ace-2545694624">Purchase Online</a>
			</div>
		</div>
		<?php get_template_part('includes/section','content');?>
	</div>
</div>

<?php get_footer();?>