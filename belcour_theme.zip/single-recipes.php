<?php get_header();?>

<div class="page-wrap">
	<div class="container mb-5">
		<h1><?php the_title();?></h1>
		<?php get_template_part('includes/section','recipes');?>
	</div>
</div>

<?php get_footer();?>