<?php if( have_posts() ): while( have_posts() ): the_post();?>
	<?php if(has_post_thumbnail()):?>
		<img src="<?php the_post_thumbnail_url('blog-small')?>" alt="<?php the_title();?>" class="img-fluid mb-3">
	<?php endif;?>
	<h2><?php the_title();?></h2>
	<?php the_excerpt();?>
	<a href="<?php the_permalink();?>">Read more</a>
	<br><br>
<?php endwhile; else: endif;?>