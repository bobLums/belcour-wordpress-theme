<?php if( have_posts() ): while( have_posts() ): the_post();?>
	<p><?php echo get_the_date('l d/m/Y');?></p>
	<?php the_content();?>
	<div class="mt-5 mb-3"><p>Author: <b><?php the_author();?></b></p></div>
	<?php $tags = get_the_tags(); if($tags): foreach($tags as $tag):?>
		<a href="<?php echo get_tag_link($tag->term_id);?>">
			<?php echo $tag->name;?>
		</a>
	<?php endforeach; endif;?>
	<div class="mt-5">
		<?php comments_template();?>
	</div>
<?php endwhile; else: endif;?>