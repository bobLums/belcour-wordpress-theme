<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Preserving Tradition</title>
		<?php wp_head();?>
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto%3A100%2C300%2C300italic%2C400%2C500%2C700&amp;ver=5.5.3" type="text/css" media="all">
	</head>
	<body>
		<header>
			<nav class="navbar navbar-expand-xl navbar-light" role="navigation">
                <div class="container">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target=".multi-collapse" aria-controls="multiCollapseExample1 multiCollapseExample2" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle navigation', 'your-theme-slug' ); ?>">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <a class="navbar-brand" href="https://belcourpreserves.com/" style="font-family: 'Droid Serif', Arial, Tahoma, sans-serif !important; color:$belcourDarkpurp; text-transform: uppercase;">Belcour Preserves</a>

                    <div class="row row-icons">
                    <a href="https://www.instagram.com/belcourpreserves/" style="margin-right: 5px;"><img src="/wordpress/wp-content/uploads/2020/11/insta.png" alt="" class="img-fluid" style="height:30px; width:100%;"></a>
                    <a href="https://www.facebook.com/BelcourPreserves"><img src="/wordpress/wp-content/uploads/2020/11/fb.png" alt="" class="img-fluid" style="height:30px; width:100%;"></a>
                    </div>
                </div>
            </nav>
		</header>


<!--
<php get_header();?>
-->

<div class="page-wrap">
	<div class="container mb-5">
        <div class="mx-auto myBanner">
            <img src="/wordpress/wp-content/uploads/2020/11/bannerSml.jpg" alt="banner" class="img-fluid" > 
        </div>
		<h1><?php the_title();?></h1>
        <h2 style="font-size:3.0rem;">SITE UNDER CONSTRUCTION</br>SOON COME...</h2>
	    <div id="tastyCarousel" class="carousel slide mb-4" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="d-block w-100" src="/wordpress/wp-content/uploads/2020/11/SalmCrmChzRolls_b_20130209_0311_lowres_web.jpg" alt="First slide">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="/wordpress/wp-content/uploads/2020/11/BrekCrepes_20130208_0125_web.jpg" alt="Second slide">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="/wordpress/wp-content/uploads/2020/11/SctchBrekky_20130210_0584_web.jpg" alt="Third slide">
                </div>
            </div>
            <a class="carousel-control-prev" href="#tastyCarousel" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#tastyCarousel" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>

        <!--
        <?php
        $args = array( 'numberposts' => 1,);
        $lastposts = get_posts( $args );
            foreach($lastposts as $post) : setup_postdata($post); ?>
                <div class="row mb-4">
                    <div class="col-4">
	                    <?php if(has_post_thumbnail()):?>
		                    <img src="<?php the_post_thumbnail_url(__('(more�)'))?>" alt="<?php the_title();?>" class="img-fluid mx-auto">
	                    <?php endif;?>
                    </div>
                    <div class="col-8">
	                    <h2><?php the_title();?></h2>
	                    <?php the_excerpt();?>
	                    <a href="<?php the_permalink();?>">Read more</a>
	                    <br><br>
                    </div>
                </div>
        <?php endforeach; ?>

        <?php
        $args2 = array( 'post_type' => 'Recipes', 
                        'numberposts' => 1 );
        $lastrecipes = get_posts( $args2 );
            foreach($lastrecipes as $post) : setup_postdata($post); ?>
                <div class="row">
                    <div class="col-4">
	                    <?php if(has_post_thumbnail()):?>
		                    <img src="<?php the_post_thumbnail_url(__('(more�)'))?>" alt="<?php the_title();?>" class="img-fluid mx-auto">
	                    <?php endif;?>
                    </div>
                    <div class="col-8">
	                    <h2><?php the_title();?></h2>
	                    <?php the_excerpt();?>
	                    <a href="<?php the_permalink();?>">Read more</a>
	                    <br><br>
                    </div>
                </div>
        <?php endforeach; ?> -->
	    </div>
</div>


<?php get_footer();?>