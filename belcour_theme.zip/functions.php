<?php

function scripts()
{
	wp_register_style('style', get_template_directory_uri() . '/dist/app.css', [], 1, 'all');
	wp_enqueue_style('style');

	wp_enqueue_script('jquery');

	wp_enqueue_script('app', get_template_directory_uri() . '/dist/app.js', ['jquery'], 1, true);
	wp_enqueue_script('app');
}
add_action('wp_enqueue_scripts','scripts');

// Theme Options

add_theme_support('menus');
add_theme_support('post-thumbnails');
add_theme_support('widgets');

// Menus

register_nav_menus(
	array(
		'main-menu' => 'Main Menu Location',
	)
);

/**
 * Register Custom Navigation Walker
 */
function register_navwalker(){
	require_once get_template_directory() . '/class-wp-bootstrap-navwalker.php';
}
add_action( 'after_setup_theme', 'register_navwalker' );

// Custom Image Sizes
add_image_size('blog-small', 300, 300, true);
add_image_size('full-width', 1140, 9999, false);

// Custom Post Types
function custom_posts()
{
	$args = array(
		'labels' => array(
						'name' => 'Recipes',
						'singualr_name' => 'Recipe',
					),
		'hierarchical' => false,
		'public' => true,
		'has_archive' => true,
		'supports' => array('title', 'comments', 'editor', 'thumbnail', 'custom-fields'),
		'taxonomies' => array('post_tag'),  
		'menu_icon' => 'dashicons-carrot',
	);
	register_post_type('recipes', $args);

	$args2 = array(
		'labels' => array(
						'name' => 'Products',
						'singualr_name' => 'Product',
					),
		'hierarchical' => true,
		'public' => true,
		'has_archive' => true,
		'supports' => array('title', 'comments', 'editor', 'thumbnail', 'custom-fields'),
		'taxonomies' => array('post_tag'),  
		'menu_icon' => 'dashicons-coffee',
	);
	register_post_type('products', $args2);
}
add_action('init', 'custom_posts');

// Custom Taxonomy
function custom_taxonomy()
{
	$args = array(
		'labels' => array(
			'name' => 'Types',
			'singular_name' => 'Type',
		),
		'public' => true,
		'hierarchical' => true,
	);
	register_taxonomy('types', array('recipes'), $args);

	$args2 = array(
		'labels' => array(
			'name' => 'Preserves',
			'singular_name' => 'Preserve',
		),
		'public' => true,
		'hierarchical' => true,
	);
	register_taxonomy('preserves', array('products'), $args2);
}
add_action('init', 'custom_taxonomy');

// Register Sidebars
function my_sidebars()
{
	register_sidebar(
		array(
			'name' => 'Page Sidebar',
			'id' => 'page-sidebar',
			'before_title' => '<h4 class="widget-title">',
			'after_title' => '</h4>'
		)
	);
	register_sidebar(
		array(
			'name' => 'Blog Sidebar',
			'id' => 'blog-sidebar',
			'before_title' => '<h4 class="widget-title">',
			'after_title' => '</h4>'
		)
	);
}
add_action('widgets_init','my_sidebars');

