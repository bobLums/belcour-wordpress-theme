<?php get_header();?>

<div class="page-wrap">
	<div class="container mb-5">
		<h1>Oops! The page is missing!</h1>
	</div>
</div>

<?php get_footer();?>