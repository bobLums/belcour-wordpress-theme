<?php get_header();?>

<div class="page-wrap">
	<div class="container mb-5">
		<h1><?php the_title();?></h1>
		<div class="row">
			<div class="col-sm-6">
				<div class="mx-auto">
					<?php if(has_post_thumbnail()):?>
						<img src="<?php the_post_thumbnail_url(__('(more�)'))?>" alt="<?php the_title();?>" class="img-fluid">
					<?php endif;?>
				</div>
			</div>
			<div class="col-sm-6">
				<h3 style="text-align:left;"><?php the_field('tagline');?></h3>
				<p><?php the_field('description');?></p>
				<h3 style="text-align:left;">Ingredients</h3>
				<p><?php the_field('ingredients');?></p>
			</div>
		</div>
		<?php get_template_part('includes/section','products');?>
	</div>
</div>

<?php get_footer();?>