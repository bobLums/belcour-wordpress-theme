<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Preserving Tradition</title>
		<?php wp_head();?>
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto%3A100%2C300%2C300italic%2C400%2C500%2C700&amp;ver=5.5.3" type="text/css" media="all">
	</head>
	<body>
		<header>
			<nav class="navbar navbar-expand-xl navbar-light" role="navigation">
                <div class="container">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target=".multi-collapse" aria-controls="multiCollapseExample1 multiCollapseExample2" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle navigation', 'your-theme-slug' ); ?>">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <a class="navbar-brand" href="http://localhost/wordpress" style="font-family: 'Droid Serif', Arial, Tahoma, sans-serif !important; color:$belcourDarkpurp; text-transform: uppercase;">Belcour Preserves</a>
                    <?php
                        wp_nav_menu( array(
                            'theme_location'    => 'main-menu',
                            'depth'             => 2,
                            'container'         => 'div',
                            'container_class'   => 'collapse navbar-collapse multi-collapse navColmarg',
                            'container_id'      => 'multiCollapseExample1',
                            'menu_class'        => 'nav navbar-nav',
                            'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
                            'walker'            => new WP_Bootstrap_Navwalker(),
                        ) );
                    ?>
                    <div class="row row-icons">
                    <a href="https://www.instagram.com/belcourpreserves/" style="margin-right: 5px;"><img src="/wordpress/wp-content/uploads/2020/11/insta.png" alt="" class="img-fluid" style="height:30px; width:100%;"></a>
                    <a href="https://www.facebook.com/BelcourPreserves"><img src="/wordpress/wp-content/uploads/2020/11/fb.png" alt="" class="img-fluid" style="height:30px; width:100%;"></a>
                    </div>
                    <div id="multiCollapseExample2" class="collapse navbar-collapse multi-collapse searcher" style="flex-grow:0"><?php get_search_form();?></div>
                </div>
            </nav>
		</header>

