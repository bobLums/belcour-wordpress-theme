	<?php wp_footer();?>

	<div class="footer">
		<div class="mx-auto mt-2"><p>Belcour Preserves &copy; <?php echo date("Y");?></p></div>
	</div>
	
	</body>
</html>